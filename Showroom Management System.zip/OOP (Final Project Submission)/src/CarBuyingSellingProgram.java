

class PurchaseForm {
    private String purchaserName;  // Name of the purchaser
    private String cnicNumber;  // CNIC number of the purchaser
    private String phoneNumber;  // Phone number of the purchaser
    private String province;  // Province of the purchaser
    private String numberPlate;  // Number plate of the purchased car
    public PurchaseForm(String purchaserName, String cnicNumber, String phoneNumber, String province, String numberPlate) {
        this.purchaserName = purchaserName;
        this.cnicNumber = cnicNumber;
        this.phoneNumber = phoneNumber;
        this.province = province;
        this.numberPlate = numberPlate;
    }

    public void displayForm() {
        System.out.println("\nPURCHASE FORM");
        System.out.println("Purchaser Name: " + purchaserName);  // Display purchaser's name
        System.out.println("CNIC Number: " + cnicNumber);  // Display purchaser's CNIC number
        System.out.println("Phone Number: " + phoneNumber);  // Display purchaser's phone number
        System.out.println("Province: " + province);  // Display purchaser's province
        System.out.println("Number Plate: " + numberPlate);  // Display purchased car's number plate
    }
}

class Car {
    protected double price;  // Price of the car
    private String brand;  // Brand of the car
    private String model;  // Model of the car
    private String color;  // Color of the car

    public Car(String brand, String model, String color, double price) {
        this.brand = brand;
        this.model = model;
        this.color = color;
        this.price = price;
    }

    public double getPrice() {
        return price;  // Return the price of the car
    }

    public String getBrand() {
        return brand;  // Return the brand of the car
    }

    public String getModel() {
        return model;  // Return the model of the car
    }

    public String getColor() {
        return color;  // Return the color of the car
    }
}

class UsedCar extends Car {
    public UsedCar(String brand, String model, String color, double price) {
        super(brand, model, color, price);
    }

    /**
     * Sell the used car and adjust the price based on the condition, transmission type, and fuel type.
     *
     * @param condition        Condition of the car (1 for excellent, 2 for good, 3 for fair)
     * @param transmissionType Transmission type of the car (1 for manual, 2 for automatic)
     * @param fuelType         Fuel type of the car (1 for petrol, 2 for diesel, 3 for hybrid)
     * @param price            Current price of the car
     */
    public void sellCar(int condition, int transmissionType, int fuelType, double price) {
        if ((transmissionType == 1 && (fuelType == 1 || fuelType == 2)) && (condition == 2 || condition == 3)) {
            price -= 25000;  // Reduce price by 25000 if condition is good or fair, and transmission type is manual with petrol or diesel fuel
        } else {
            price -= 10000;  // Reduce price by 10000 for other cases
        }
        super.price = price;  // Update the price of the used car
    }
}


