import java.util.ArrayList;
import java.util.List;    
import java.util.Random;
import java.util.Scanner;

public class Main  {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        List<PurchaseForm> purchaseHistory = new ArrayList<>();
        List<PurchaseForm> sellHistory = new ArrayList<>();
        int choice;

        // Display the welcome message
        do {
            System.out.println("\t\t\t\t\t\t ************************************************** ");
            System.out.println(" \t\t\t\t\t\t*                                                * ");
            System.out.println(" \t\t\t\t\t\t\t\t*    Welcome to Car Showroom     * ");
            System.out.println(" \t\t\t\t\t\t*                                                * ");
            System.out.println(" \t\t\t\t\t\t************************************************** ");
        } while (false);

        do {
            // Display the main menu
            System.out.println("\nMAIN MENU");
            System.out.println("1. Buy");
            System.out.println("2. Sell");
            System.out.println("3. Main Menu");
            System.out.println("4. Buy History");
            System.out.println("5. Sell History");
            System.out.println("0. Exit ");

            System.out.println("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    // Buy a car
                    System.out.println("Choose the brand:");
                    System.out.println("1. Toyota");
                    System.out.println("2. Honda");
                    System.out.println("3. Ford");
                    int brandChoice = scanner.nextInt();
                    scanner.nextLine();

                    String brandToBuy;
                    switch (brandChoice) {
                        case 1:
                            brandToBuy = "Toyota";
                            break;
                        case 2:
                            brandToBuy = "Honda";
                            break;
                        case 3:
                            brandToBuy = "Ford";
                            break;
                        default:
                            System.out.println("Invalid brand choice. Returning to the main menu.");
                            continue;
                    }

                    // Get details of the car to buy
                    System.out.println("Enter the model of the car you want to buy: ");
                    String modelToBuy = scanner.nextLine();

                    System.out.println("Enter the color of the car you want to buy: ");
                    String colorToBuy = scanner.nextLine();

                    System.out.println("Choose the fuel type:");
                    System.out.println("1. Petrol");
                    System.out.println("2. Diesel");
                    System.out.println("3. Electric");
                    int fuelTypeToBuy = scanner.nextInt();
                    scanner.nextLine();

                    System.out.println("Choose the transmission type:");
                    System.out.println("1. Manual");
                    System.out.println("2. Automatic");
                    int transmissionTypeToBuy = scanner.nextInt();
                    scanner.nextLine();

                    // Generate a random price for the car
                    int priceToBuy = random.nextInt(500000) + 500000;
                    if (fuelTypeToBuy == 3 && transmissionTypeToBuy == 1) {
                        priceToBuy += 50000;
                    } else if (fuelTypeToBuy == 3 && transmissionTypeToBuy == 2) {
                        priceToBuy += 100000;
                    }

                    // Display buy form details
                    System.out.println("\nBuy Form:");
                    System.out.println("Brand: " + brandToBuy);
                    System.out.println("Model: " + modelToBuy);
                    System.out.println("Color: " + colorToBuy);
                    System.out.println("Fuel Type: " + (fuelTypeToBuy == 1 ? "Petrol" : (fuelTypeToBuy == 2 ? "Diesel" : "Electric")));
                    System.out.println("Transmission Type: " + (transmissionTypeToBuy == 1 ? "Manual" : "Automatic"));
                    System.out.println("Price: $" + priceToBuy);

                    System.out.println("Choose the payment method:");
                    System.out.println("1. Debit Card Transaction");
                    System.out.println("2. Cheque");
                    int paymentMethod = scanner.nextInt();
                    scanner.nextLine();

                    String paymentMethodStr = (paymentMethod == 1) ? "Debit Card Transaction" : "Cheque";

                    // Get purchaser information
                    String purchaserName;
                    String cnicNumber;
                    String phoneNumber;
                    String province;

                    System.out.println("Enter the purchaser name: ");
                    purchaserName = scanner.nextLine();

                    System.out.println("Enter the CNIC number: ");
                    cnicNumber = scanner.nextLine();

                    System.out.println("Enter the phone number: ");
                    phoneNumber = scanner.nextLine();

                    System.out.println("Choose the province: ");
                    System.out.println("1. Sindh");
                    System.out.println("2. Punjab");
                    System.out.println("3. Balochistan");
                    System.out.println("4. KPK");
                    System.out.println("5. Gilgit Baltistan");
                    int provinceChoice = scanner.nextInt();
                    scanner.nextLine();

                    switch (provinceChoice) {
                        case 1:
                            province = "Sindh";
                            break;
                        case 2:
                            province = "Punjab";
                            break;
                        case 3:
                            province = "Balochistan";
                            break;
                        case 4:
                            province = "KPK";
                            break;
                        case 5:
                            province = "Gilgit Baltistan";
                            break;
                        default:
                            System.out.println("Invalid province choice. Returning to the main menu.");
                            continue;
                    }

                    // Generate a number plate for the car
                    String numberPlate = generateNumberPlate();
                    PurchaseForm purchaseForm = new PurchaseForm(purchaserName, cnicNumber, phoneNumber, province, numberPlate);
                    purchaseHistory.add(purchaseForm);

                    // Display purchase confirmation
                    System.out.println("\nThank you for your purchase!");
                    System.out.println("Your car's number plate is: " + numberPlate);
                    System.out.println("Payment Method: " + paymentMethodStr);

                    break;

                case 2:
                    // Sell a car
                    System.out.println("Enter the details of the car you want to sell:");

                    System.out.println("Enter the brand: ");
                    String brandToSell = scanner.nextLine();

                    System.out.println("Enter the model: ");
                    String modelToSell = scanner.nextLine();

                    System.out.println("Enter the car number plate: ");
                    String numberPlateToSell = scanner.nextLine();


                    System.out.println("Enter the color: ");
                    String colorToSell = scanner.nextLine();

                    System.out.println("Choose the transmission type:");
                    System.out.println("1. Manual");
                    System.out.println("2. Automatic");
                    int transmissionTypeToSell = scanner.nextInt();
                    scanner.nextLine();

                    System.out.println("Choose the fuel type:");
                    System.out.println("1. Petrol");
                    System.out.println("2. Diesel");
                    System.out.println("3. Electric");
                    int fuelTypeToSell = scanner.nextInt();
                    scanner.nextLine();

                    System.out.println("Choose the condition:");
                    System.out.println("1. Excellent");
                    System.out.println("2. Good");
                    System.out.println("3. Average");
                    int condition = scanner.nextInt();
                    scanner.nextLine();

                    System.out.println("Enter the price: ");
                    int priceToSell = scanner.nextInt();
                    scanner.nextLine();

                    // Create a used car object and sell it
                    UsedCar usedCar = new UsedCar(brandToSell, modelToSell, colorToSell, priceToSell);
                    usedCar.sellCar(condition, transmissionTypeToSell, fuelTypeToSell, priceToSell);

                    // Display sell form details
                    System.out.println("\nSell Form:");
                    System.out.println("Brand: " + usedCar.getBrand());
                    System.out.println("Model: " + usedCar.getModel());
                    System.out.println("Color: " + usedCar.getColor());
                    System.out.println("Transmission Type: " + (transmissionTypeToSell == 1 ? "Manual" : "Automatic"));
                    System.out.println("Fuel Type: " + (fuelTypeToSell == 1 ? "Petrol" : (fuelTypeToSell == 2 ? "Diesel" : "Electric")));
                    System.out.println("Condition: " + (condition == 1 ? "Excellent" : (condition == 2 ? "Good" : "Average")));
                    System.out.println("Number Plate entered: " + numberPlateToSell);
                    System.out.println("Price: $" + usedCar.getPrice());

                    System.out.println("Choose the payment method:");
                    System.out.println("1. Debit Card Transaction");
                    System.out.println("2. Cheque");
                    paymentMethod = scanner.nextInt();
                    scanner.nextLine();

                    paymentMethodStr = (paymentMethod == 1) ? "Debit Card Transaction" : "Cheque";

                    // Get seller information
                    System.out.println("Enter the seller name: ");
                    String sellerName = scanner.nextLine();

                    System.out.println("Enter the CNIC number: ");
                    String sellerCnicNumber = scanner.nextLine();

                    System.out.println("Enter the phone number: ");
                    String sellerPhoneNumber = scanner.nextLine();

                    System.out.println("Choose the province: ");
                    System.out.println("1. Sindh");
                    System.out.println("2. Punjab");
                    System.out.println("3. Balochistan");
                    System.out.println("4. KPK");
                    System.out.println("5. Gilgit Baltistan");
                    int sellerProvinceChoice = scanner.nextInt();
                    scanner.nextLine();

                    String sellerProvince;
                    switch (sellerProvinceChoice) {
                        case 1:
                            sellerProvince = "Sindh";
                            break;
                        case 2:
                            sellerProvince = "Punjab";
                            break;
                        case 3:
                            sellerProvince = "Balochistan";
                            break;
                        case 4:
                            sellerProvince = "KPK";
                            break;
                        case 5:
                            sellerProvince = "Gilgit Baltistan";
                            break;
                        default:
                            System.out.println("Invalid province choice. Returning to the main menu.");
                            continue;
                    }

                    // Generate a number plate for the sold car
                    String sellerNumberPlate = generateNumberPlate();
                    PurchaseForm sellForm = new PurchaseForm(sellerName, sellerCnicNumber, sellerPhoneNumber, sellerProvince, sellerNumberPlate);
                    sellHistory.add(sellForm);

                    // Display sell confirmation
                 System.out.println("\nThank you for selling your car!");
                       System.out.println("Number Plate entered: " + numberPlateToSell);
                    System.out.println("Payment Method: " + paymentMethodStr);

                    break;

                case 3:
                    System.out.println("Returning to the main menu.");
                    break;

                case 4:
                    // Display buy history
                    System.out.println("\nBUY HISTORY");
                    for (int i = 0; i < purchaseHistory.size(); i++) {
                        System.out.println("Form " + (i + 1) + ":");
                        purchaseHistory.get(i).displayForm();
                        System.out.println();
                    }
                    break;

                case 5:
                    // Display sell history
                    System.out.println("\nSELL HISTORY");
                    for (int i = 0; i < sellHistory.size(); i++) {
                        System.out.println("Form " + (i + 1) + ":");
                        sellHistory.get(i).displayForm();
                        System.out.println();
                    }
                    break;

                case 0:
                    System.out.println("Thank you for using the Car Showroom application. Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }

        } while (choice != 0);
    }

    // Generate a random number plate for the car
    public static String generateNumberPlate() {
        Random random = new Random();
        StringBuilder numberPlate = new StringBuilder();

        // Generate 3 random uppercase letters
        for (int i = 0; i < 3; i++) {
            char c = (char) (random.nextInt(26) + 'A');
            numberPlate.append(c);
        }

        // Generate 4 random digits
        for (int i = 0; i < 4; i++) {
            int digit = random.nextInt(10);
            numberPlate.append(digit);
        }

        return numberPlate.toString();
    }
}